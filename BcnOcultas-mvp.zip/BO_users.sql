USE bo_users;
ALTER TABLE usuarios
MODIFY COLUMN email VARCHAR(100) NULL;

ALTER TABLE usuarios
MODIFY COLUMN password VARCHAR(32) NULL;


INSERT INTO usuarios (numero_usuario, user_name, email, telefono, direccion, fecha_creacion, activo)
VALUES
    (101, 'sinestesia.barcelona', 'info@sinestesia.barcelona', NULL, 'C/ Santa Caterina 52/54 08014 Barcelona', NOW(), 1),
    (102, 'bodegasalto.net', 'info@bodegasalto.net', '934413709', 'C/Blesa, 36 Poble-sec Barcelona', NOW(), 1),
    (103, 'craftbarcelona.com', 'info@craftbarcelona.com', '655 50 00 32', 'Carrer de Paradís, 4, 08002 Barcelona', NOW(), 1),
	(104, 'soda.cat', 'info@soda.cat', '930 165 590', 'Carrer de les Guilleries 6, 08012 Barcelona', NOW(), 1),
    (105, 'diobarbcn.com', 'diobar@diobarbcn.cat', '656 621 145', 'Av. del Marquès de l\Argentera, 27, 08003 Barcelona', NOW(), 1),
    (106, 'Perro Pako Bar', NULL, '696442751', 'Carrer de les flors 16 barcelona, Barcelona, Spain', NOW(), 1),
    (107, 'sala-upload.com', NULL, NULL, 'Av. Francesc Ferrer i Guàrdia 13, 08038 Barcelona', NOW(), 1),
    (108, 'Mariatchi', NULL, NULL, 'Carrer Còdols 14, Barcelona', NOW(), 1),
    (109, 'casa.hydra', NULL, '677011363', 'Carrer Pallars 84, Barcelona', NOW(), 1),
    (110, 'bigbangbarcelona.com', NULL, NULL, 'Carrer d\En Botella, 7, Ciutat Vella, 08001 Barcelona', NOW(), 1),
    (111, 'raiassociacio.org', 'dinamitzacio@raiassociacio.org', NULL, 'C/ Carders 12 principal 08003 Barcelona', NOW(), 1),
    (112, 'freedonia.eu', 'info@freedonia.eu', NULL, 'Carrer Lleialtat 6, Barcelona, Spain, 08001', NOW(), 1),
    (113, 'ra.co', NULL, NULL, '© 2025 Resident Advisor Ltd. All rights reserved', NOW(), 1),
    (114, 'cooperativalaraiz.org', 'raizbarbcn@gmail.com', NULL, 'C/ Nou de la Rambla 154, Sants-Montjuïc, 08004-Bcn', NOW(), 1),
    (115, 'elpumarejo.org', 'info@elpumarejo.com', NULL, 'Av. Carrilet, 187 – Nau 4, 08907 L’Hospitalet de Llobregat', NOW(), 1),
    (116, 'bcnmes.com', 'info@bcnmes.com', NULL, 'Carrer Radas 12, 08004 Barcelona', NOW(), 1),
    (117, 'barcelona.lecool.com', 'bcn@lecool.com', NULL, NULL, NOW(), 1);


