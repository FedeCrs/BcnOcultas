SELECT * FROM BO_users.usuarios;

INSERT INTO usuarios (user_name, email, password, id, numero_usuario, telefono, direccion, fecha_creacion, activo)
VALUES ('aclamclub.cat', 'club@aclam.cat', NULL, 52, 118, '93 017 37 92', 'Calle del Consell de Cent 201, 08011 Barcelona', '2025-05-14 20:27:22', 1);

